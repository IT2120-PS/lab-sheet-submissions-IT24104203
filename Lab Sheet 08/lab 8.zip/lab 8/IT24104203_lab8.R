setwd("C:\\Users\\IT24104203\\Desktop\\lab 8")
weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
fix(weights)
attach(weights)
# extract weight column
w <- weights$Weight.kg.


#Q1

pop_mean <- mean(w)
pop_sd <- sd(w)

print("Q1: population mean and SD")
print(pop_mean)
print(pop_sd)


#Q2

set.seed(42) #for reproducibility

sample_means <- c()
sample_sds <- c()

for(i in 1:25){
  samp <- sample(w, size = 6, replace = TRUE)
  sample_means[i] <- mean(samp)
  sample_sds[i] <- sd(samp)
}

print("Q2: sample means(25 samples)")
print(sample_means)

print("Q2: sample SDs(25 samples)")
print(sample_sds)


#Q3

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

print("Q3: mean of sample means")
print(mean_of_sample_means)

print("Q3: SD of sample means")
print(sd_of_sample_means)

print("relationship:")
print(" - mean of sample means ≈ population mean")
print(" - SD of sample means < population SD")
