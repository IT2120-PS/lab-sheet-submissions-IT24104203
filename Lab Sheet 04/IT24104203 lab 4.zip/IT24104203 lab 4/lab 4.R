setwd("C:\\Users\\IT24104203\\Desktop\\IT24104203 lab 4")
branch_data<-read.table("Exercise.txt", header = TRUE, sep = ",")
attach(branch_data)
head(branch_data)

boxplot(Sales_X1,
        main = "Boxplot of sales",
        ylab = "sales",
        col = "lightblue")


summary(Advertising_X2)
IQR(Advertising_X2)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_val
  upper <- Q3 + 1.5 * IQR_val
  return(x[x < lower | x > upper])
}
find_outliers(Years_X3)

